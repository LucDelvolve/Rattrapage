-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le :  sam. 22 juin 2019 à 12:41
-- Version du serveur :  10.1.35-MariaDB
-- Version de PHP :  7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `bddmedicament`
--

-- --------------------------------------------------------

--
-- Structure de la table `maladie`
--

CREATE TABLE `maladie` (
  `numMaladie` int(10) NOT NULL,
  `nomMaladie` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS POUR LA TABLE `maladie`:
--

--
-- Déchargement des données de la table `maladie`
--

INSERT INTO `maladie` (`numMaladie`, `nomMaladie`) VALUES
(1, 'Gastro-entérite'),
(2, 'Angine'),
(3, 'Bronchite'),
(4, 'Grippe'),
(5, 'Mal de dos'),
(6, 'Rhinopharyngite');

-- --------------------------------------------------------

--
-- Structure de la table `medicament`
--

CREATE TABLE `medicament` (
  `numMedicament` int(10) NOT NULL,
  `nomMedicament` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS POUR LA TABLE `medicament`:
--

--
-- Déchargement des données de la table `medicament`
--

INSERT INTO `medicament` (`numMedicament`, `nomMedicament`) VALUES
(1, 'Vogalib'),
(2, 'Nausicalm'),
(3, 'Primpéran'),
(4, 'Motilium'),
(5, 'Péridys'),
(6, 'Paracétamol'),
(7, 'Drill'),
(8, 'Streptsils'),
(9, 'Eludril'),
(10, 'Humex'),
(11, 'Echinacée '),
(12, 'Ginseng ');

-- --------------------------------------------------------

--
-- Structure de la table `prescrire`
--

CREATE TABLE `prescrire` (
  `codeMaladie` int(10) NOT NULL,
  `codeMedicament` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- RELATIONS POUR LA TABLE `prescrire`:
--   `codeMaladie`
--       `maladie` -> `numMaladie`
--   `codeMedicament`
--       `medicament` -> `numMedicament`
--

--
-- Déchargement des données de la table `prescrire`
--

INSERT INTO `prescrire` (`codeMaladie`, `codeMedicament`) VALUES
(1, 1),
(1, 2),
(1, 3),
(1, 4),
(2, 3),
(2, 4),
(2, 5),
(2, 6),
(2, 7),
(2, 8),
(3, 4),
(3, 9),
(3, 11),
(4, 3),
(4, 5),
(5, 6),
(5, 8),
(5, 10),
(6, 2),
(6, 10),
(6, 11),
(6, 12);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `maladie`
--
ALTER TABLE `maladie`
  ADD PRIMARY KEY (`numMaladie`);

--
-- Index pour la table `medicament`
--
ALTER TABLE `medicament`
  ADD PRIMARY KEY (`numMedicament`);

--
-- Index pour la table `prescrire`
--
ALTER TABLE `prescrire`
  ADD PRIMARY KEY (`codeMaladie`,`codeMedicament`),
  ADD KEY `codeMedicament` (`codeMedicament`);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `prescrire`
--
ALTER TABLE `prescrire`
  ADD CONSTRAINT `prescrire_ibfk_1` FOREIGN KEY (`codeMaladie`) REFERENCES `maladie` (`numMaladie`),
  ADD CONSTRAINT `prescrire_ibfk_2` FOREIGN KEY (`codeMedicament`) REFERENCES `medicament` (`numMedicament`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
